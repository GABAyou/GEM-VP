# GEM-VP-OthelloSphere-2.0

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019d0350-8538-768b-8f05-bc50471ff56f](https://codepen.io/editor/GABAyou/pen/019d0350-8538-768b-8f05-bc50471ff56f).

