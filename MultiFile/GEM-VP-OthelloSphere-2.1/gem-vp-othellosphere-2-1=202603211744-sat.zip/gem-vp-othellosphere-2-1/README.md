# GEM-VP-OthelloSphere-2.1

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019d0dd7-01a8-7469-8eb3-5063faaf983a](https://codepen.io/editor/GABAyou/pen/019d0dd7-01a8-7469-8eb3-5063faaf983a).

