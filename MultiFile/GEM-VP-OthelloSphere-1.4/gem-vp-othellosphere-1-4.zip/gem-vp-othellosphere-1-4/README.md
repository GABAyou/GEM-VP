# GEM-VP-OthelloSphere-1.4

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019ce476-6b95-7527-9f6d-d52d1fb843dd](https://codepen.io/editor/GABAyou/pen/019ce476-6b95-7527-9f6d-d52d1fb843dd).

