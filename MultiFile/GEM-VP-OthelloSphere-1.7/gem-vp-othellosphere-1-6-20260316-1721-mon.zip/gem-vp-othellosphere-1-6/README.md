# GEM-VP-OthelloSphere-1.6

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019cf3d5-2316-712c-8b98-b0f06ebddfac](https://codepen.io/editor/GABAyou/pen/019cf3d5-2316-712c-8b98-b0f06ebddfac).

