# GEM-VP-OthelloSphere-1.8

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019cf92f-5916-777f-9c0b-87a32ffe1ffb](https://codepen.io/editor/GABAyou/pen/019cf92f-5916-777f-9c0b-87a32ffe1ffb).

