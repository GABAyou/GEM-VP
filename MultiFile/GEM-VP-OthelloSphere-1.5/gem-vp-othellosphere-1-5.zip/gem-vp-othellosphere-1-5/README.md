# GEM-VP-OthelloSphere-1.5

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019ceec6-f1d6-7027-a6fe-f04c4544e17b](https://codepen.io/editor/GABAyou/pen/019ceec6-f1d6-7027-a6fe-f04c4544e17b).

