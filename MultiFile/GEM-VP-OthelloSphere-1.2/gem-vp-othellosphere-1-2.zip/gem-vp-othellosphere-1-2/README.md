# GEM-VP-OthelloSphere-1.2

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019ce440-0294-77b6-a440-8be0c1795b98](https://codepen.io/editor/GABAyou/pen/019ce440-0294-77b6-a440-8be0c1795b98).

