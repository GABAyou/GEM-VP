# GEM-VP-24

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GABAyou/pen/019ccfa5-f594-7c4c-b1dc-1ff8c817469d](https://codepen.io/editor/GABAyou/pen/019ccfa5-f594-7c4c-b1dc-1ff8c817469d).

